#!/bin/bash
echo "=== 安装依赖环境 ==="
pip install -r requirements.txt

echo "=== 启动 Web 前端服务 ==="
cd app
python app.py
