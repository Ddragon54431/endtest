# Cross-Domain Few-Shot Detection

This is a cross-domain few-shot object detection framework with domain adaptation and prompt learning.